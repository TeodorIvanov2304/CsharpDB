﻿namespace Footballers.Data.Models.Enums
{
    public enum BestSkillType
    {
        Defence = 0, 
        Dribble, 
        Pass, 
        Shoot, 
        Speed
    }
}
