﻿namespace Footballers.DataProcessor.ExportDto
{
    public class ExportTeamFootballersDto
    {
        public string FootballerName { get; set; }
        public string ContractStartDate { get; set; }
        public string ContractEndDate { get; set; }
        public string BestSkillType { get; set; }
        public string PositionType { get; set; }
    }
}
